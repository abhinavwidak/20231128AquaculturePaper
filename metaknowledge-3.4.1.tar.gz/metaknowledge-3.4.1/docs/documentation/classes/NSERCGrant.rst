NSERCGrant(Grant)
=============================


.. autoclass:: metaknowledge.grants.NSERCGrant
   :members:
   :special-members:
   :private-members: