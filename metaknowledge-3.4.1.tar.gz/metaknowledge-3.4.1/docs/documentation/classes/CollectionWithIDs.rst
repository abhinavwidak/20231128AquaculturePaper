CollectionWithIDs(Collection)
=============================


.. autoclass:: metaknowledge.CollectionWithIDs
   :members:
   :special-members:
   :private-members: