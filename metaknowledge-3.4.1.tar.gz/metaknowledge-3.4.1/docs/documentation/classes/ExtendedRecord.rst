ExtendedRecord(Record)
======================


.. autoclass:: metaknowledge.ExtendedRecord
   :members:
   :special-members:
   :private-members: