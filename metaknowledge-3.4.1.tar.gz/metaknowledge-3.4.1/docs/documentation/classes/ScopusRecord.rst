ScopusRecord(ExtendedRecord)
============================


.. autoclass:: metaknowledge.scopus.ScopusRecord
   :members:
   :special-members:
   :private-members: