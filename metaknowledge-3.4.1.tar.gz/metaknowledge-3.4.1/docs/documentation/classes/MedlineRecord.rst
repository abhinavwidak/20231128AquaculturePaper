MedlineRecord(ExtendedRecord)
=============================


.. autoclass:: metaknowledge.medline.MedlineRecord
   :members:
   :special-members:
   :private-members: