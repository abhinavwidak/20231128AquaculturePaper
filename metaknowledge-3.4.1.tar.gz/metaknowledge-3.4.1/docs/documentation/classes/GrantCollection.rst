GrantCollection(CollectionWithIDs)
==================================


.. autoclass:: metaknowledge.GrantCollection
   :members:
   :special-members:
   :private-members: