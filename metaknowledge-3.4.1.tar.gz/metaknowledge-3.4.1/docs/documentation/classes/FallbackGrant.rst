FallbackGrant(Grant)
======================


.. autoclass:: metaknowledge.grants.FallbackGrant
   :members:
   :special-members:
   :private-members:
