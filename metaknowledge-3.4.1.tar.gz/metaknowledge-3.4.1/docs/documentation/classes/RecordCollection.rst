RecordCollection(CollectionWithIDs)
===================================


.. autoclass:: metaknowledge.RecordCollection
   :members:
   :special-members:
   :private-members: