Record(Mapping, Hashable)
=============================


.. autoclass:: metaknowledge.Record
   :members:
   :special-members:
   :private-members: