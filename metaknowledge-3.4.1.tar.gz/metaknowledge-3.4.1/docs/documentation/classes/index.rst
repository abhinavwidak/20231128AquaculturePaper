Classes
*******

.. toctree::
   :maxdepth: 2

   CIHRGrant
   Citation
   Collection
   CollectionWithIDs
   ExtendedRecord
   FallbackGrant
   Grant
   GrantCollection
   MedlineGrant
   MedlineRecord
   NSERCGrant
   NSFGrant
   ProQuestRecord
   Record
   RecordCollection
   ScopusRecord
   WOSRecord