WOSRecord(ExtendedRecord)
=============================


.. autoclass:: metaknowledge.WOS.WOSRecord
   :members:
   :special-members:
   :private-members: