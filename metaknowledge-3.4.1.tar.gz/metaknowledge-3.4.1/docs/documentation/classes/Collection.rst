Collection(MutableSet, Hashable)
================================


.. autoclass:: metaknowledge.Collection
   :members:
   :special-members:
   :private-members: