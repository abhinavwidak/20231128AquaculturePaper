Grant(Record, MutableMapping)
=============================

.. automodule:: metaknowledge.grants

.. autoclass:: metaknowledge.grants.Grant
   :members:
   :special-members:
   :private-members: