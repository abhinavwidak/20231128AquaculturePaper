Citation(Hashable)
==================


.. automodule:: metaknowledge.citation
   :members:
   :special-members:
   :private-members: