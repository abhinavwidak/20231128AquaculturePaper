ProQuestRecord(ExtendedRecord)
==============================


.. autoclass:: metaknowledge.proquest.ProQuestRecord
   :members:
   :special-members:
   :private-members: