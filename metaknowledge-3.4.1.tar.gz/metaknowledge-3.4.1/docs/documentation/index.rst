Documentation
*************


.. toctree::
   :maxdepth: 1

   
   example
   overview
   modules/index
   classes/index
   functions_methods/index
   exceptions/index