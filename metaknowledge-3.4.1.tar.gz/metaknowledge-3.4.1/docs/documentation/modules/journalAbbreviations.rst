journalAbbreviations
==========================================


Overview
---------------
.. automodule:: metaknowledge.journalAbbreviations

Functions
---------
.. automodule:: metaknowledge.journalAbbreviations.backend
   :members:
