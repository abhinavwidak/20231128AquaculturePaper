WOS
===

Overview
--------
.. automodule:: metaknowledge.WOS

Functions
---------

.. automodule:: metaknowledge.WOS.wosHandlers
   :members:
   
Help Functions
--------------

.. automodule:: metaknowledge.WOS.tagProcessing.helpFuncs
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   
Tag Functions
-------------

.. automodule:: metaknowledge.WOS.tagProcessing.tagFunctions
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   
Dict Functions
--------------

.. automodule:: metaknowledge.WOS.tagProcessing.funcDicts
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   
Backend
-------

.. automodule:: metaknowledge.WOS.recordWOS
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members: