proquest
========

Overview
--------
.. automodule:: metaknowledge.proquest

Functions
---------

.. automodule:: metaknowledge.proquest.proQuestHandlers
   :members:
   
Special Functions
-----------------

.. automodule:: metaknowledge.proquest.tagProcessing.specialFunctions
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   
Tag Functions
-------------

.. automodule:: metaknowledge.proquest.tagProcessing.tagFunctions
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   
Backend
-------

.. automodule:: metaknowledge.proquest.recordProQuest
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
