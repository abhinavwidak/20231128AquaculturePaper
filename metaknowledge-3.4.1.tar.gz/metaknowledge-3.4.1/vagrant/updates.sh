#!/usr/bin/env bash

echo "Updating"
echo "No updates found"

exit 0
