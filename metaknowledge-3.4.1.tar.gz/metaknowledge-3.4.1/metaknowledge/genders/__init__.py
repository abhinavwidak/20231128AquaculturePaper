#Written by Reid McIlroy-Young for Dr. John McLevey, University of Waterloo 2016
from .nameGender import nameStringGender, recordGenders, downloadData, getMapping
