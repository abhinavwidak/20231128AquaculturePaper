#Written by Reid McIlroy-Young for Dr. John McLevey, University of Waterloo 2015
